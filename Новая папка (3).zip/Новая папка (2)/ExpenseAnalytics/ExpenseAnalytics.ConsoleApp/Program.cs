using System.Globalization;
using ExpenseAnalytics.Core;

var shell = new ConsoleShell(InitialData.Create());
shell.Run();

internal static class InitialData
{
    public static List<Expense> Create() => new()
    {
        new(1, new DateOnly(2026, 10, 1), "Продукты",     "Покупки в магазине", 1800m),
        new(2, new DateOnly(2026, 10, 2), "Транспорт",    "Проезд",              150m),
        new(3, new DateOnly(2026, 10, 3), "Развлечения",  "Кино",                700m),
        new(4, new DateOnly(2026, 10, 4), "Продукты",     "Покупки на рынке",   1200m),
        new(5, new DateOnly(2026, 10, 5), "Образование",  "Книга",              1600m),
        new(6, new DateOnly(2026, 10, 6), "Транспорт",    "Такси",               600m),
        new(7, new DateOnly(2026, 10, 7), "Развлечения",  "Концерт",            2500m),
        new(8, new DateOnly(2026, 10, 8), "Продукты",     "Кофе",                250m),
    };
}

internal sealed class ConsoleShell
{
    private IReadOnlyList<Expense> _expenses;

    public ConsoleShell(IReadOnlyList<Expense> initial) => _expenses = initial;

    public void Run()
    {
        while (true)
        {
            PrintMenu();
            var cmd = Console.ReadLine()?.Trim();
            switch (cmd)
            {
                case "1": ShowAll(); break;
                case "2": Add(); break;
                case "3": Select(); break;
                case "4": ShowReport(); break;
                case "0": return;
                case null: return;
                default: Console.WriteLine("Неизвестная команда."); break;
            }
        }
    }

    private static void PrintMenu()
    {
        Console.WriteLine();
        Console.WriteLine("1 — Показать все расходы");
        Console.WriteLine("2 — Добавить расход");
        Console.WriteLine("3 — Отобрать расходы");
        Console.WriteLine("4 — Сформировать отчёт");
        Console.WriteLine("0 — Завершить работу");
        Console.Write("Выбор: ");
    }

    private void ShowAll()
    {
        var ordered = _expenses.OrderBy(e => e.Date).ThenBy(e => e.Id).ToList();
        PrintExpenses(ordered);
    }

    private static void PrintExpenses(IReadOnlyList<Expense> list)
    {
        if (list.Count == 0)
        {
            Console.WriteLine("(список пуст)");
            return;
        }
        foreach (var e in list)
            Console.WriteLine($"{e.Id,4}  {e.Date:dd.MM.yyyy}  {e.Category,-15}  {e.Description,-25}  {e.Amount}");
    }

    private void Add()
    {
        var date = ReadValidatedInput("Дата (dd.MM.yyyy): ", ParseDate);
        
        Console.Write("Категория: ");
        var category = Console.ReadLine() ?? "";
        
        Console.Write("Описание: ");
        var description = Console.ReadLine() ?? "";
        
        var amount = ReadValidatedInput("Сумма: ", ParseDecimal);

        var input = new NewExpenseInput(category, description, amount);
        var errors = Functions.ValidateAll(input, Validation.NewExpenseRules);
        if (errors.Count > 0)
        {
            foreach (var err in errors) Console.WriteLine($"Ошибка: {err}");
            Console.WriteLine("Расход не добавлен.");
            return;
        }

        var newId = _expenses.Count == 0 ? 1 : _expenses.Max(e => e.Id) + 1;
        var expense = new Expense(newId, date, category.Trim(), description.Trim(), amount);
        _expenses = Functions.AppendImmutable(_expenses, expense);
        Console.WriteLine($"Добавлен расход с Id={newId}.");
    }

    private void Select()
    {
        var criteria = ReadCriteriaWithValidation();
        PrintExpenses(Selection.Filter(_expenses, criteria));
    }

    private void ShowReport()
    {
        var criteria = ReadCriteriaWithValidation();
        var filtered = Selection.Filter(_expenses, criteria);
        PrintReport(Reports.Build(filtered));
    }

    private static ExpenseCriteria ReadCriteriaWithValidation()
    {
        while (true)
        {
            var c = ReadCriteria();
            if (c.FromDate is { } from && c.ToDate is { } to && from > to)
            {
                Console.WriteLine("Дата начала позже даты окончания. Повторите ввод.");
                continue;
            }
            return c;
        }
    }

    private static ExpenseCriteria ReadCriteria()
    {
        var from = ReadOptionalInput("Дата начала (dd.MM.yyyy, пусто — без ограничения): ", ParseDate);
        var to = ReadOptionalInput("Дата окончания (dd.MM.yyyy, пусто — без ограничения): ", ParseDate);
        
        Console.Write("Категория (пусто — любая): ");
        var rawCat = Console.ReadLine();
        var category = string.IsNullOrWhiteSpace(rawCat) ? null : rawCat;
        
        var min = ReadOptionalInput("Мин. сумма (пусто — без ограничения): ", ParseDecimal);
        
        return new ExpenseCriteria(from, to, category, min);
    }

    private static T ReadValidatedInput<T>(string prompt, Func<string, (bool Success, T Value, string Error)> parser)
    {
        while (true)
        {
            Console.Write(prompt);
            var input = Console.ReadLine() ?? "";
            var (success, value, error) = parser(input);
            
            if (success) return value;
            Console.WriteLine(error);
        }
    }

    private static T? ReadOptionalInput<T>(string prompt, Func<string, (bool Success, T Value, string Error)> parser) where T : struct
    {
        while (true)
        {
            Console.Write(prompt);
            var input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) return null;
            
            var (success, value, error) = parser(input);
            if (success) return value;
            Console.WriteLine(error);
        }
    }

    private static (bool Success, DateOnly Value, string Error) ParseDate(string input)
    {
        return DateOnly.TryParseExact(input, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d)
            ? (true, d, string.Empty)
            : (false, default, "Некорректная дата. Повторите ввод.");
    }

    private static (bool Success, decimal Value, string Error) ParseDecimal(string input)
    {
        return decimal.TryParse(input, out var d)
            ? (true, d, string.Empty)
            : (false, default, "Некорректная сумма. Повторите ввод.");
    }

    private static void PrintReport(ExpenseReport r)
    {
        Console.WriteLine($"Количество расходов: {r.Count}");
        Console.WriteLine($"Общая сумма: {r.Total}");
        Console.WriteLine($"Средняя сумма: {(r.Average is { } avg ? avg.ToString("0.##") : "нет данных")}");

        Console.WriteLine("Суммы по категориям:");
        if (r.ByCategory.Count == 0) Console.WriteLine("  (нет данных)");
        else foreach (var c in r.ByCategory)
            Console.WriteLine($"  {c.Category}: {c.Total}");

        Console.WriteLine("Три крупнейших расхода:");
        if (r.TopExpenses.Count == 0) Console.WriteLine("  (нет данных)");
        else foreach (var e in r.TopExpenses)
            Console.WriteLine($"  Id {e.Id}: {e.Category} — {e.Description} — {e.Amount} ({e.Date:dd.MM.yyyy})");

        Console.WriteLine("Дневные суммы и накопленный итог:");
        if (r.DailyTotals.Count == 0) Console.WriteLine("  (нет данных)");
        else foreach (var d in r.DailyTotals)
            Console.WriteLine($"  {d.Date:dd.MM.yyyy}: {d.DayTotal} — итого {d.RunningTotal}");
    }
}