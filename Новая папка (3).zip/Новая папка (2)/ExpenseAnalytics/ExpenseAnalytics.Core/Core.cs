﻿namespace ExpenseAnalytics.Core;

public record Expense(int Id, DateOnly Date, string Category, string Description, decimal Amount);

public record NewExpenseInput(string Category, string Description, decimal Amount);

public record ExpenseCriteria(
    DateOnly? FromDate = null,
    DateOnly? ToDate = null,
    string? Category = null,
    decimal? MinAmount = null);

public record CategoryTotal(string Category, decimal Total);

public record DailyTotal(DateOnly Date, decimal DayTotal, decimal RunningTotal);

public record ExpenseReport(
    int Count,
    decimal Total,
    decimal? Average,
    IReadOnlyList<CategoryTotal> ByCategory,
    IReadOnlyList<Expense> TopExpenses,
    IReadOnlyList<DailyTotal> DailyTotals);

public static class Functions
{
    public static Predicate<T> AllOf<T>(IReadOnlyList<Predicate<T>> predicates)
    {
        var copy = new List<Predicate<T>>(predicates);
        return value =>
        {
            foreach (var p in copy)
                if (!p(value)) return false;
            return true;
        };
    }

    public static List<string> ValidateAll<T>(T value, IReadOnlyList<Func<T, string?>> rules)
    {
        var errors = new List<string>();
        foreach (var rule in rules)
        {
            var error = rule(value);
            if (error is not null) errors.Add(error);
        }
        return errors;
    }

    public static (TState FinalState, List<TResult> Items) MapAccum<T, TState, TResult>(
        IEnumerable<T> source,
        TState initialState,
        Func<TState, T, (TState NextState, TResult Item)> step)
    {
        var state = initialState;
        var items = new List<TResult>();
        foreach (var item in source)
        {
            var (next, result) = step(state, item);
            state = next;
            items.Add(result);
        }
        return (state, items);
    }

    public static List<T> AppendImmutable<T>(IReadOnlyList<T> source, T item)
    {
        var result = new List<T>(source.Count + 1);
        foreach (var x in source) result.Add(x);
        result.Add(item);
        return result;
    }
}

public static class Validation
{
    public static readonly IReadOnlyList<Func<NewExpenseInput, string?>> NewExpenseRules =
        new List<Func<NewExpenseInput, string?>>
        {
            v => string.IsNullOrWhiteSpace(v.Category) ? "Категория не должна быть пустой." : null,
            v => string.IsNullOrWhiteSpace(v.Description) ? "Описание не должно быть пустым." : null,
            v => v.Amount > 0 ? null : "Сумма должна быть больше нуля."
        };
}

public static class Selection
{
    public static Predicate<Expense> BuildPredicate(ExpenseCriteria criteria)
    {
        var predicates = new List<Predicate<Expense>>();
        if (criteria.FromDate is { } from)
            predicates.Add(e => e.Date >= from);
        if (criteria.ToDate is { } to)
            predicates.Add(e => e.Date <= to);
        if (criteria.Category is { } category)
        {
            var normalized = category.Trim();
            predicates.Add(e => string.Equals(e.Category.Trim(), normalized, StringComparison.OrdinalIgnoreCase));
        }
        if (criteria.MinAmount is { } min)
            predicates.Add(e => e.Amount >= min);
        return Functions.AllOf(predicates);
    }

    public static List<Expense> Filter(IEnumerable<Expense> source, ExpenseCriteria criteria)
    {
        var selection = BuildPredicate(criteria);
        return source.Where(e => selection(e)).ToList();
    }
}

public static class Reports
{
    public static ExpenseReport Build(IReadOnlyList<Expense> expenses)
    {
        var count = expenses.Count;
        var total = expenses.Sum(e => e.Amount);
        decimal? average = count == 0 ? null : total / count;

        var byCategory = expenses
            .GroupBy(e => e.Category.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => new CategoryTotal(g.Key, g.Sum(e => e.Amount)))
            .OrderByDescending(c => c.Total)
            .ThenBy(c => c.Category, StringComparer.OrdinalIgnoreCase)
            .ToList();

        var top = expenses
            .OrderByDescending(e => e.Amount)
            .ThenBy(e => e.Id)
            .Take(3)
            .ToList();

        var dailySource = expenses
            .GroupBy(e => e.Date)
            .Select(g => new { Date = g.Key, Total = g.Sum(e => e.Amount) })
            .OrderBy(d => d.Date)
            .ToList();

        var (_, daily) = Functions.MapAccum(
            dailySource,
            0m,
            (running, d) =>
            {
                var next = running + d.Total;
                return (next, new DailyTotal(d.Date, d.Total, next));
            });

        return new ExpenseReport(count, total, average, byCategory, top, daily);
    }
}
